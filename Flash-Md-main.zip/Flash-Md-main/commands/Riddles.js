const _0x22abf3 = _0x10bc;
(function (_0x41a183, _0x5437d4) {
    const _0x1876c2 = _0x10bc, _0x45058a = _0x41a183();
    while (!![]) {
        try {
            const _0x107f29 = parseInt(_0x1876c2(0x1e2)) / (-0x1 * 0x21ec + 0x22b1 + 0x1 * -0xc4) * (parseInt(_0x1876c2(0x208)) / (-0x9 * 0xe0 + 0x9 * -0x1df + -0x1 * -0x18b9)) + -parseInt(_0x1876c2(0x203)) / (0xddb + 0x2e * 0x57 + -0x1d7a) + -parseInt(_0x1876c2(0x20b)) / (0x9 * 0x166 + 0x2122 + -0x64 * 0x75) * (parseInt(_0x1876c2(0x1b0)) / (0x2034 + 0xee6 + -0x2f15)) + parseInt(_0x1876c2(0x193)) / (-0x20 * 0x12e + -0x36 * -0xa1 + 0x3d0) + parseInt(_0x1876c2(0x16f)) / (-0xfb8 + 0x21af + 0x2 * -0x8f8) + parseInt(_0x1876c2(0x220)) / (0x1998 + 0x719 + -0x20a9 * 0x1) + parseInt(_0x1876c2(0x1f2)) / (0xb0f * -0x1 + 0x204b + -0x1533 * 0x1) * (parseInt(_0x1876c2(0x1a6)) / (0x1a * 0xb6 + -0x1b51 + 0x2f5 * 0x3));
            if (_0x107f29 === _0x5437d4)
                break;
            else
                _0x45058a['push'](_0x45058a['shift']());
        } catch (_0x3da935) {
            _0x45058a['push'](_0x45058a['shift']());
        }
    }
}(_0x59b3, 0x86 * -0x20 + -0x2 * -0x85691 + -0x1 * 0x3a0d9));
function _0x10bc(_0x5e9f72, _0x75c866) {
    const _0x3b12fa = _0x59b3();
    return _0x10bc = function (_0x131025, _0x1e1952) {
        _0x131025 = _0x131025 - (-0xd5 * -0xf + 0x1b1 * 0x1 + -0xccc);
        let _0xfd2131 = _0x3b12fa[_0x131025];
        return _0xfd2131;
    }, _0x10bc(_0x5e9f72, _0x75c866);
}
const {king} = require(_0x22abf3(0x195) + _0x22abf3(0x18e)), devinettes = [
        {
            'question': _0x22abf3(0x180) + _0x22abf3(0x1db) + _0x22abf3(0x182) + _0x22abf3(0x1a4),
            'reponse': _0x22abf3(0x1bc) + 'r'
        },
        {
            'question': _0x22abf3(0x1bd) + _0x22abf3(0x207) + _0x22abf3(0x1e4) + _0x22abf3(0x164) + _0x22abf3(0x1b4) + _0x22abf3(0x1b1) + _0x22abf3(0x19b),
            'reponse': _0x22abf3(0x1c4) + 'le'
        },
        {
            'question': _0x22abf3(0x192) + _0x22abf3(0x1be) + _0x22abf3(0x163) + _0x22abf3(0x1ab) + _0x22abf3(0x1d5) + _0x22abf3(0x185) + '\x20?',
            'reponse': _0x22abf3(0x1ff) + '\x206'
        },
        {
            'question': _0x22abf3(0x17d) + _0x22abf3(0x205) + _0x22abf3(0x170) + _0x22abf3(0x20e) + _0x22abf3(0x1f8) + _0x22abf3(0x1af) + _0x22abf3(0x1c3) + _0x22abf3(0x21d) + _0x22abf3(0x16e) + _0x22abf3(0x19e) + _0x22abf3(0x1f9) + _0x22abf3(0x171),
            'reponse': _0x22abf3(0x1a8)
        },
        {
            'question': _0x22abf3(0x166) + _0x22abf3(0x1d2) + _0x22abf3(0x1d0) + _0x22abf3(0x1ef) + _0x22abf3(0x21f) + _0x22abf3(0x1e0) + _0x22abf3(0x1f0) + _0x22abf3(0x18f) + _0x22abf3(0x211) + _0x22abf3(0x1f6) + _0x22abf3(0x1a1) + _0x22abf3(0x189) + _0x22abf3(0x162),
            'reponse': _0x22abf3(0x20a) + _0x22abf3(0x167)
        },
        {
            'question': _0x22abf3(0x21a) + _0x22abf3(0x1fe) + _0x22abf3(0x1c1) + _0x22abf3(0x1eb) + _0x22abf3(0x175) + _0x22abf3(0x168) + _0x22abf3(0x162),
            'reponse': _0x22abf3(0x215)
        },
        {
            'question': _0x22abf3(0x1e5) + _0x22abf3(0x1a5) + _0x22abf3(0x1e6) + _0x22abf3(0x21c) + _0x22abf3(0x1c8) + _0x22abf3(0x20f) + _0x22abf3(0x1da) + _0x22abf3(0x162),
            'reponse': _0x22abf3(0x1fd)
        },
        {
            'question': _0x22abf3(0x1dd) + _0x22abf3(0x204) + _0x22abf3(0x19a) + _0x22abf3(0x1ca) + _0x22abf3(0x1a3) + _0x22abf3(0x199) + _0x22abf3(0x1a2) + _0x22abf3(0x1f4) + _0x22abf3(0x1c2) + _0x22abf3(0x1e3),
            'reponse': _0x22abf3(0x1f1)
        },
        {
            'question': _0x22abf3(0x1ba) + _0x22abf3(0x17b) + _0x22abf3(0x1ee) + _0x22abf3(0x1a7) + _0x22abf3(0x218) + _0x22abf3(0x1b8) + _0x22abf3(0x1e8) + _0x22abf3(0x1c9) + _0x22abf3(0x16d) + _0x22abf3(0x20d),
            'reponse': _0x22abf3(0x1fc)
        },
        {
            'question': _0x22abf3(0x181) + _0x22abf3(0x1d9) + _0x22abf3(0x1b6) + _0x22abf3(0x1d3) + _0x22abf3(0x19d) + _0x22abf3(0x1ec) + _0x22abf3(0x1fb) + _0x22abf3(0x18b) + _0x22abf3(0x214) + _0x22abf3(0x20d),
            'reponse': _0x22abf3(0x201) + _0x22abf3(0x176)
        },
        {
            'question': _0x22abf3(0x21e) + _0x22abf3(0x18a) + _0x22abf3(0x219) + _0x22abf3(0x198) + _0x22abf3(0x1cf) + _0x22abf3(0x1d4) + _0x22abf3(0x202),
            'reponse': _0x22abf3(0x20a) + _0x22abf3(0x1de)
        },
        {
            'question': _0x22abf3(0x1d8) + _0x22abf3(0x1cc) + _0x22abf3(0x1f7) + _0x22abf3(0x1ce) + _0x22abf3(0x1c0) + _0x22abf3(0x165) + _0x22abf3(0x1b7) + _0x22abf3(0x17f) + '?',
            'reponse': _0x22abf3(0x1b3) + 'h'
        },
        {
            'question': _0x22abf3(0x1bb) + _0x22abf3(0x1c5) + _0x22abf3(0x212) + _0x22abf3(0x191) + _0x22abf3(0x20d),
            'reponse': _0x22abf3(0x1d6)
        },
        {
            'question': _0x22abf3(0x1df) + _0x22abf3(0x184) + _0x22abf3(0x1bf) + _0x22abf3(0x1d1) + _0x22abf3(0x1ae) + _0x22abf3(0x18c) + _0x22abf3(0x161) + _0x22abf3(0x17c) + _0x22abf3(0x1e3),
            'reponse': _0x22abf3(0x206)
        },
        {
            'question': _0x22abf3(0x21a) + _0x22abf3(0x1fe) + _0x22abf3(0x1c1) + _0x22abf3(0x1eb) + _0x22abf3(0x175) + _0x22abf3(0x168) + _0x22abf3(0x177),
            'reponse': _0x22abf3(0x215)
        },
        {
            'question': _0x22abf3(0x180) + _0x22abf3(0x17a) + _0x22abf3(0x1e7) + _0x22abf3(0x1d7) + _0x22abf3(0x1ac) + _0x22abf3(0x194) + _0x22abf3(0x216) + _0x22abf3(0x178),
            'reponse': _0x22abf3(0x1c6)
        },
        {
            'question': _0x22abf3(0x16a) + _0x22abf3(0x1b5) + _0x22abf3(0x1fa) + _0x22abf3(0x210) + _0x22abf3(0x1dc) + _0x22abf3(0x162),
            'reponse': _0x22abf3(0x20a) + _0x22abf3(0x19f)
        },
        {
            'question': _0x22abf3(0x181) + _0x22abf3(0x1d9) + _0x22abf3(0x1b6) + _0x22abf3(0x1d3) + _0x22abf3(0x19d) + _0x22abf3(0x1ec) + _0x22abf3(0x1fb) + _0x22abf3(0x18b) + _0x22abf3(0x214) + _0x22abf3(0x20d),
            'reponse': _0x22abf3(0x201) + _0x22abf3(0x176)
        },
        {
            'question': _0x22abf3(0x1cb) + _0x22abf3(0x1c7) + _0x22abf3(0x197) + _0x22abf3(0x174) + _0x22abf3(0x19c) + _0x22abf3(0x172) + _0x22abf3(0x21b) + _0x22abf3(0x17f) + '?',
            'reponse': _0x22abf3(0x200)
        },
        {
            'question': _0x22abf3(0x21a) + _0x22abf3(0x1fe) + _0x22abf3(0x1c1) + _0x22abf3(0x1eb) + _0x22abf3(0x175) + _0x22abf3(0x168) + _0x22abf3(0x162),
            'reponse': _0x22abf3(0x215)
        },
        {
            'question': _0x22abf3(0x1e5) + _0x22abf3(0x1a5) + _0x22abf3(0x1e6) + _0x22abf3(0x21c) + _0x22abf3(0x1c8) + _0x22abf3(0x20f) + _0x22abf3(0x1da) + _0x22abf3(0x162),
            'reponse': _0x22abf3(0x190)
        },
        {
            'question': _0x22abf3(0x166) + _0x22abf3(0x1d2) + _0x22abf3(0x1a9) + _0x22abf3(0x1f3) + _0x22abf3(0x173) + _0x22abf3(0x196) + _0x22abf3(0x1a0) + _0x22abf3(0x209) + _0x22abf3(0x1e1) + _0x22abf3(0x1aa) + _0x22abf3(0x1b9) + _0x22abf3(0x16b) + _0x22abf3(0x18d),
            'reponse': _0x22abf3(0x20c) + _0x22abf3(0x1f5)
        },
        {
            'question': _0x22abf3(0x1d8) + _0x22abf3(0x1cc) + _0x22abf3(0x1f7) + _0x22abf3(0x1ce) + _0x22abf3(0x1c0) + _0x22abf3(0x165) + _0x22abf3(0x1b7) + _0x22abf3(0x17f) + '?',
            'reponse': _0x22abf3(0x1b3) + 'h'
        }
    ];
king({
    'nomCom': _0x22abf3(0x1ed),
    'categorie': _0x22abf3(0x169)
}, async (_0x1afcc6, _0x5e5814, _0x340161) => {
    const _0x24416d = _0x22abf3, _0x506b51 = {
            'ETdxw': function (_0x3caa21, _0x294346) {
                return _0x3caa21 * _0x294346;
            },
            'AhgWh': function (_0x2af252, _0x4e02ba) {
                return _0x2af252(_0x4e02ba);
            }
        }, {
            ms: _0x470b7a,
            repondre: _0x6d0e2e
        } = _0x340161, _0x531bd9 = devinettes[Math[_0x24416d(0x179)](_0x506b51[_0x24416d(0x1cd)](Math[_0x24416d(0x213)](), devinettes[_0x24416d(0x1b2)]))];
    await _0x5e5814[_0x24416d(0x1ad) + 'e'](_0x1afcc6, { 'text': _0x24416d(0x217) + _0x531bd9[_0x24416d(0x188)] + (_0x24416d(0x187) + _0x24416d(0x186) + _0x24416d(0x1ea) + _0x24416d(0x17e)) }, { 'quoted': _0x470b7a }), await _0x506b51[_0x24416d(0x16c)](delay, -0x3718 + -0x2 * -0x4ef3 + -0x107 * -0xe), await _0x5e5814[_0x24416d(0x1ad) + 'e'](_0x1afcc6, { 'text': _0x24416d(0x1e9) + _0x24416d(0x183) + _0x531bd9[_0x24416d(0x160)] }, { 'quoted': _0x470b7a });
});
function delay(_0x49dda2) {
    return new Promise(_0x595059 => setTimeout(_0x595059, _0x49dda2));
}
function _0x59b3() {
    const _0x532649 = [
        '9843208ybABxB',
        'reponse',
        'ls\x20into\x20wi',
        '\x20I\x20?',
        'down,\x20but\x20',
        'eat,\x20the\x20f',
        'nd\x20when\x20yo',
        'I\x20am\x20the\x20b',
        '\x20\x27e\x27',
        'an.\x20Who\x20am',
        'Games',
        'I\x20start\x20at',
        'space.\x20Who',
        'AhgWh',
        'o\x20fish.\x20Wh',
        'en\x20to\x20expe',
        '3558485dCzeOu',
        'ng,\x20hard\x20o',
        'ho\x20am\x20I\x20?',
        '\x20and\x20even\x20',
        'd\x20of\x20every',
        ',\x20the\x20air,',
        'n\x20I\x20am\x20cle',
        '\x20book',
        '\x20I?',
        'I\x20?',
        'floor',
        'without\x20ha',
        'ns,\x20but\x20no',
        'ngs.\x20Who\x20a',
        'I\x20can\x20be\x20s',
        'ink\x20about.',
        '\x20Who\x20am\x20I\x20',
        'I\x20can\x20fly\x20',
        'I\x20can\x20be\x20r',
        'ngs,\x20who\x20a',
        '\x20was\x20:\x20',
        'tuff\x20of\x20dr',
        '.\x20Who\x20am\x20I',
        'ave\x2030\x20sec',
        '\x20.\x20\x0a\x20you\x20h',
        'question',
        'ce.\x20Who\x20am',
        'ce\x20in\x20a\x20we',
        't\x20rarely\x20k',
        'change\x20sou',
        '\x20am\x20I\x20?',
        'king',
        'ing\x20of\x20ete',
        'tea',
        'become.\x20Wh',
        'I\x27m\x20strong',
        '104718ZNRQZb',
        'having\x20eye',
        '../france/',
        '\x20place.\x20I\x20',
        '\x20around\x20me',
        'n\x20a\x20year,\x20',
        'I\x20am,\x20deat',
        '\x20I\x20cry\x20wit',
        'am\x20I\x20?',
        '\x20the\x20earth',
        '\x20me.\x20You\x20a',
        'rienced\x20mu',
        '\x20\x27N\x27',
        'am\x20the\x20beg',
        'me\x20and\x20spa',
        'h\x20always\x20a',
        '\x20Wherever\x20',
        'm\x20I?',
        ',\x20but\x20if\x20y',
        '2273830txaILp',
        '\x20have\x20moun',
        'A\x20pencil',
        'f\x20the\x20end\x20',
        'the\x20end\x20of',
        'I\x27m\x20weak\x20w',
        'y\x20without\x20',
        'sendMessag',
        '\x20ideas.\x20I\x20',
        'd\x20by\x20anyon',
        '102255FyoaJV',
        'come.\x20Who\x20',
        'length',
        'Your\x20breat',
        'atter\x20I\x20be',
        '\x20night\x20and',
        'ou\x20can\x27t\x20w',
        'u\x20find\x20me.',
        '\x20no\x20trees.',
        '\x20time\x20and\x20',
        'I\x20have\x20tow',
        'The\x20hotter',
        'The\x20weathe',
        'I\x27m\x20always',
        '\x20when\x20I\x27m\x20',
        'eams.\x20I\x20co',
        'in\x20your\x20ha',
        '\x20dirty\x20and',
        '\x20me.\x20Who\x20a',
        'e,\x20from\x20yo',
        'A\x20black\x20ho',
        '\x20I\x20am,\x20the',
        'A\x20cloud',
        'everything',
        'rom\x20me,\x20I\x20',
        'ter,\x20but\x20n',
        'hout\x20eyes.',
        'I\x20feed\x20on\x20',
        'o\x20grasp,\x20b',
        'ETdxw',
        'l\x20hold\x20me\x20',
        'but\x20never\x20',
        'f\x20the\x20end,',
        'ver\x20broken',
        'eginning\x20o',
        'rite\x20about',
        'in\x20a\x20day.\x20',
        'hen\x20I\x27m\x20up',
        'coffe',
        '.\x20I\x20can\x20cr',
        'I\x27m\x20hard\x20t',
        'ead,\x20but\x20y',
        'id.\x20Who\x20am',
        'without\x20wi',
        'ng.\x20Who\x20am',
        'I\x20fly\x20with',
        '\x20\x27E\x27',
        'I\x20am\x20the\x20s',
        'ace.\x20I\x20am\x20',
        'eternity,\x20',
        '23948DzjTNa',
        'm\x20I\x20?',
        'he\x20more\x20I\x20',
        'I\x27m\x20liquid',
        'ou\x20take\x20wa',
        'ving\x20wings',
        '\x20I\x20have\x20wa',
        'The\x20answer',
        'onds\x20to\x20th',
        '\x20black\x20whe',
        'lways\x20give',
        'riddle',
        '\x20houses.\x20I',
        '\x20the\x20end\x20o',
        'the\x20beginn',
        'The\x20wind',
        '36QytKmx',
        'and\x20the\x20en',
        'ccompanies',
        '\x27E\x27',
        '\x20end\x20of\x20ti',
        'ut\x20you\x20wil',
        'can\x20be\x20use',
        'sicians.\x20W',
        '\x20finish\x20in',
        '\x20to\x20me,\x20bu',
        'A\x20map',
        'Tea',
        '\x20when\x20I\x20am',
        'The\x20number',
        'a\x20fire',
        'A\x20borrowed',
        'Who\x20am\x20I\x20?',
        '3868026xdGbhe',
        'out\x20wings,',
        'hort\x20or\x20lo',
        'A\x20book',
        '\x20hungry,\x20t',
        '62bISJex',
        'inning\x20of\x20',
        'The\x20letter',
        '248makvxS',
        'the\x20letter',
        'o\x20am\x20I\x20?',
        'r\x20soft,\x20I\x20',
        'become\x20sol',
        '\x20the\x20morni',
        'rnity,\x20the',
        '\x20colder\x20I\x20',
        'random',
        'eep\x20me.\x20Wh',
        'A\x20slate',
        's.\x20Who\x20am\x20',
        'Riddle:\x20',
        'tains,\x20but',
        'ek,\x20once\x20i',
        'I\x20am\x20white',
        'the\x20trees.',
        'ter\x20away\x20f',
        'ung\x20childr',
        'I\x20come\x20twi',
        'f\x20every\x20pl'
    ];
    _0x59b3 = function () {
        return _0x532649;
    };
    return _0x59b3();
}
