<h1 align="center"> 𝐓𝐇𝐄 𝐅𝐋𝐀𝐒𝐇 𝐌𝐔𝐋𝐓𝐈 𝐃𝐄𝐕𝐈𝐂𝐄  </h1>
<p align="center">  
  
***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR CHOOSING +FLASH-MD;MULTI+DEVICE+WHATSAPP+BOT;CREATED+BY+FRANCE+KING;RELEASED+22.2.2024" alt="Typing SVG" /></a>
  </p>
    <img alt="FLASH-MD" width="700" height="300" src="https://telegra.ph/file/3f985014b51b3cf335bfe.jpg">
<p align="center">
<p align="center">
<a href="https://github.com/franceking1/Flash-Md"><img title="Author" src="https://img.shields.io/badge/FLASH_MD-black?style=for-the-badge&logo=github"></a>
<p/>
<p align="center">
<a href="https://github.com/franceking1?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/franceking1?label=Followers&style=social"></a>
<a href="https://github.com/franceking1/Flash-Md/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/franceking1/Flash-Md?&style=social"></a>
<a href="https://github.com/franceking1/Flash-Md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/franceking1/Flash-Md?style=social"></a>
<a href="https://github.com/franceking1/Flash-Md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/franceking1/Flash-Md?label=Watching&style=social"></a>
  
***

#### SETUP 

***1.`First STAR 🌟 This Repo ` And Then [`FORK`](https://github.com/franceking1/Flash-Md/fork) It***

***2.`GET SESSION_ID USING`***
[`QR SCANNER`](https://the-flash-scanner.onrender.com) OR [`PAIRING CODE`](https://king-france.vercel.app)
 
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

***

#### DEPLOY TO HEROKU 
**1. If You Don't Have An Account On Heroku**

- <a align="center"><a href="https://signup.heroku.com">
 <img src="https://img.shields.io/badge/Create%20Account%20Now-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

**2. If You Have a Heroku Account**
  - <a align="center"><a href="https://france-king.vercel.app"> <img src="https://img.shields.io/badge/DEPLOY%20NOW-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


***

#### DEPLOY ON RENDER 
**1. If You Don't Have An Account On Render**
- <a href="https://dashboard.render.com/register"><img src="https://img.shields.io/badge/CREATE AN ACCOUNT NOW-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

**2. If You Have an account on Render**
- <a href="https://render.com"><img title="Deploy Now" src="https://img.shields.io/badge/DEPLOY NOW-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

**3.Create an account on UPTIME TO MAKE YOUR RENDER BOT STABLE**
- <a href="https://uptimerobot.com"><img title="Deploy Now" src="https://img.shields.io/badge/CREATE NOW-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

**4. Join our telegram Channel and watch tutorials on how to deploy**
- <a href="https://t.me/france_king1"><img title="Author" src="https://img.shields.io/badge/JOIN NOW-black?style=for-the-badge&logo=Telegram"></a>



***


### 🛡️ DISCLAIMER 🛡 
-Copying or modifying this repo is at your own risk,as we won't offer any support! 
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

***

### DEVELOPER:
**GET In Touch with The Owner**
- <a href="https://instagram.com/france.king1"><img title="Author" src="https://img.shields.io/badge/ON INSTAGRAM-black?style=for-the-badge&logo=Instagram"></a>
- OR 
- <a href="https://wa.me/254742063632" target="_blank">
    <img alt="CLICK HERE" src="https://img.shields.io/badge/ On WhatsApp  -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

***

#### SUPPORT THE PROJECT 
1. **JOIN OUR SUPPORT GROUP**
- <a href="https://chat.whatsapp.com/IH4xWuVTGpf7ibfzC3h6LM" target="_blank">
    <img alt="CLICK HERE" src="https://img.shields.io/badge/ JOIN NOW 🚀 -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
  
2. **FOLLOW OUR WHATSAPP CHANNEL**

- <a href="https://whatsapp.com/channel/0029VaTbb3p84Om9LRX1jg0P" target="_blank">
    <img alt="CLICK HERE " src="https://img.shields.io/badge/ FOLLOW NOW  -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

***
### THANKS TO:
- [***Fortunatus Mokaya***](https://github.com/Fortunatusmokaya) For several Cmds from his bot & Ideas.
- [***Gifted Tech***](https://github.com/mouricedevs) For Genaral Help and Brotherhood. 
- [***Suhail Ser***](https://github.com/SuhailTechInfo) For Code encryption. 
- [***Luffy***](https://github.com/Luffy2ndAccount) For Providing a Base of **FLASH-MD**

